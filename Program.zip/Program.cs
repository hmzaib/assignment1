﻿using System;
public class MyClass{
    public static void Main()
    {
        var name="zaiba";
        Console.WriteLine($"Hello world this is {name}");
        Console.ReadKey();
    }
}
